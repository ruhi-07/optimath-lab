import math
import pytest
from optics import *

def test_focal_length():
    assert focal_length_m(2) == 0.5
    assert math.isinf(focal_length_m(0))

def test_combined_lenses():
    assert combined_power(5, 2) == 7
    assert combined_power(5, 2, 0.01) == pytest.approx(6.9)

def test_vergence():
    assert vergence_after_lens(-2, 5) == 3

def test_vectors():
    assert power_vectors(-2, -2, 0) == pytest.approx((-3, 1, 0))
    assert power_vectors(-2, -2, 90) == pytest.approx((-3, -1, 0))
    with pytest.raises(ValueError):
        power_vectors(0, -1, 180)

def test_acuity():
    assert snellen_to_logmar(6, 6) == pytest.approx(0)
    assert snellen_to_logmar(6, 60) == pytest.approx(1)
    assert logmar_to_decimal(1) == pytest.approx(0.1)
    with pytest.raises(ValueError):
        snellen_to_logmar(0, 6)

def test_scaling():
    assert retinal_scale_mm_per_pixel(12, 1200) == pytest.approx(0.01)
    with pytest.raises(ValueError):
        retinal_scale_mm_per_pixel(12, 0)
