# 👁️ OptiMath Lab

**Interactive mathematical ophthalmology — an open-source educational toolkit.**

Explore optical power, astigmatism power vectors, visual acuity conversions, and retinal image scaling with interactive graphs.

> ⚠️ Educational/research demonstration only. **Not clinically validated.** Never use this software to diagnose, prescribe, plan treatment, or make patient-care decisions.

## Features

| Module | Mathematics |
| --- | --- |
| Lens optics | `F_eq = F1 + F2 - d F1 F2`, `f = 1/F` |
| Astigmatism | `M = S + C/2`, `J0 = -(C/2) cos(2a)`, `J45 = -(C/2) sin(2a)` |
| Visual acuity | `logMAR = log10(denominator/numerator)` |
| Retinal scaling | `mm/pixel = assumed field width (mm) / image width (pixels)` |

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements-dev.txt
streamlit run app.py
```

## Tests

```bash
python -m pytest -q
```

## Deploy

1. Upload this folder's contents to a public GitHub repository.
2. Visit https://share.streamlit.io and sign in with GitHub.
3. Select **Create app**, choose your repository, branch `main`, and entrypoint `app.py`.
4. Deploy and share the resulting URL.

## Assumptions and limitations

- Thin paraxial lenses in air; separated-lens equation ignores thick-lens and aberration effects.
- Power vectors use a consistent spherocylinder sign and axis convention.
- Snellen conversions are algebraic and do not model clinical measurement variability.
- Retinal pixel scaling assumes the true field width is known and ignores magnification and geometric distortion.
- No patient data are collected or stored by this application.
- No clinical validation, regulatory assessment, or quality-management process has been performed.

## Possible next steps

Add scientific references, independent numerical validation, CI, sample data, and peer review before making stronger scientific claims.

## License

MIT — see [LICENSE](LICENSE).
