"""Educational optics calculations. Not for clinical decision-making."""
import math

def focal_length_m(power_d):
    if power_d == 0:
        return math.inf
    return 1.0 / power_d

def combined_power(p1, p2, separation_m=0.0):
    return p1 + p2 - separation_m * p1 * p2

def vergence_after_lens(incident_d, lens_d):
    return incident_d + lens_d

def power_vectors(sphere, cylinder, axis_deg):
    if not 0 <= axis_deg < 180:
        raise ValueError('Axis must be in [0, 180) degrees')
    angle = math.radians(2 * axis_deg)
    return (sphere + cylinder / 2, -cylinder / 2 * math.cos(angle), -cylinder / 2 * math.sin(angle))

def snellen_to_logmar(numerator, denominator):
    if numerator <= 0 or denominator <= 0:
        raise ValueError('Snellen values must be positive')
    return math.log10(denominator / numerator)

def logmar_to_decimal(logmar):
    return 10 ** (-logmar)

def retinal_scale_mm_per_pixel(field_width_mm, image_width_px):
    if field_width_mm <= 0 or image_width_px <= 0:
        raise ValueError('Dimensions must be positive')
    return field_width_mm / image_width_px
